text_suffixes = [
    'txt',
    'md',
    'markdown'
]

office_suffixes = [
    'doc',
    'docx',
    'ppt',
    'pptx',
    'xls',
    'xlsx',
    'pdf',
    'odt',
    'ods',
    'odp',
]

ZERO_OBJ_ID = '0000000000000000000000000000000000000000'
